import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.io.*; 
import java.net.*; 
import java.util.*; 
import java.util.concurrent.ConcurrentLinkedQueue; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class ShooterClient extends PApplet {






String host = "jlot.tk";
int port = 13821;
ConcurrentLinkedQueue<Player> players = new ConcurrentLinkedQueue<Player>();
ConcurrentLinkedQueue<Bullet> localBullets = new ConcurrentLinkedQueue<Bullet>();
ConcurrentLinkedQueue<Bullet> allBullets = new ConcurrentLinkedQueue<Bullet>();
Player localPlayer = null;
Socket s;
OutputStream outStream;
InputStream inStream;
Syncer syncer;
Thread t;

public void addPlayer(Player p)
{
  players.add(p);
}
// https://www.javarticles.com/2015/07/java-convert-long-into-bytes.html
public void pushLongIntoByteArray(long l, byte[] b, int start)
{
  b[start+7] = (byte)l;
  //println((byte)l);
  l>>>=8;
  b[start+6] = (byte)l;
  //println((byte)l);
  l>>>=8;
  b[start+5] = (byte)l;
  //println((byte)l);
  l>>>=8;
  b[start+4] = (byte)l;
  //println((byte)l);
  l>>>=8;
  b[start+3] = (byte)l;
  //println((byte)l);
  l>>>=8;
  b[start+2] = (byte)l;
  //println((byte)l);
  l>>>=8;
  b[start+1] = (byte)l;
  //println((byte)l);
  l>>>=8;
  b[start] = (byte)l;
  //println((byte)l);
}
public static long readLongFromByteArray(byte[] b, int start)
{
    //System.out.println("Reading long!");
    long val = 0;
    for(int i = 0; i < 8; i++)
    {
        int currentByte = (b[start++]&0xFF);
        val<<=8;
        val+=currentByte;
    }
    return val;
}

public void updatePlayer()
{
  try
  {
    if (keyPressed)
    {
      PVector spd = new PVector(0, 0);
      //println(key);
      if (key == 'w' || key == 'W')
      {
        spd.y = -3;
      }
      if (key == 's' || key == 'S')
      {
        spd.y = 3;
      }
      if (key == 'a' || key == 'A')
      {
        spd.x = -3;
      }
      if (key == 'd' || key == 'D')
      {
        spd.x = 3;
      }
      if (spd.x == localPlayer.velocity.x && spd.y == localPlayer.velocity.y)
      {
        return;
      }
      localPlayer.velocity = spd;
      sendPlayerUpdate();
    }
  }
  catch(Exception e)
  {
     print("abc"); 
  }
}


int regularCooldown = 5;
int shotgunCooldown = 20;
long fireAgain = 0;
public void setup()
{
  
  frameRate(40);
  fireAgain = -regularCooldown;
  localPlayer = new Player(new PVector(30, 30), new PVector(0,0), (byte)20,System.currentTimeMillis());
  randomSeed(localPlayer.id);
  addPlayer(localPlayer);
  try {
    s = new Socket(host, port);
    outStream = s.getOutputStream();
    inStream = s.getInputStream();
    syncer = new Syncer(inStream);
    t = new Thread(syncer);
    t.start();
    sendPlayerUpdate();
  } 
  catch (IOException e) {
    println("Verbindungsfehler");
  }
}
//List<Rect> boxes;
ArrayList<Bullet> bulletsThatHit;
ArrayList<Player> playersThatWereHit;
int bulletTTL = 15;
public void draw()
{
  if(localPlayer.hp <= 0)
  {
     localPlayer.pos = new PVector(0,0);
     sendPlayerUpdate();
     setPlayerHealth(localPlayer,(byte)(100));
     println("Player health < 0");
  }
  rectMode(CENTER);  
  if(!closed)
  {
    if(mousePressed)
    {
      if(frameCount > fireAgain)
      {
        if(mouseButton == LEFT)
        {
          fireAgain = frameCount+regularCooldown;
          Bullet b = new Bullet(
                          new PVector(localPlayer.pos.x,localPlayer.pos.y),
                          new PVector(mouseX - width/2, mouseY - height/2).normalize().mult(10),
                          (byte)5,(long)random(0,localPlayer.id),frameCount+bulletTTL);
          sendCreateNewBullet(b);
          localBullets.add(b);
          allBullets.add(b);
        }
        else
        {
          fireAgain = frameCount+regularCooldown;
          
           for(int i = 0; i < 5; i++)
           {
               Bullet b = new Bullet(
                          new PVector(localPlayer.pos.x,localPlayer.pos.y),
                          new PVector(mouseX - width/2+random(-40,40), mouseY - height/2+random(-40,40)).normalize().mult(10),
                          (byte)5,(long)random(0,localPlayer.id),frameCount+(int)(bulletTTL*random(0.75f,2f)));
              sendCreateNewBullet(b);
              localBullets.add(b);
              allBullets.add(b);
           }
        }
      }
    }
    updatePlayer();
    background(255);
    //println("Player count: " + players.size());
    int i = 0;
    bulletsThatHit = new ArrayList<Bullet>();
    playersThatWereHit = new ArrayList<Player>();
    for (Player p : this.players)
    {
      
      ellipse(p.pos.x-localPlayer.pos.x+width/2, p.pos.y-localPlayer.pos.y+height/2, p.size, p.size);
      fill(255,100,0);
      rect(p.pos.x-localPlayer.pos.x+width/2, p.pos.y-localPlayer.pos.y+height/2-25, p.hp, 15);
      fill(0,0,0);
      textAlign(CENTER);
      text(p.hp+"/100",p.pos.x-localPlayer.pos.x+width/2, p.pos.y-localPlayer.pos.y+height/2-20, p.hp);
      //ellipse(p.pos.x, p.pos.y, p.size, p.size);
      //println("player "+ p.id +"  at: X: " + p.pos.x + " Y: " + p.pos.y); 
      fill(0,0,0);
      textAlign(CENTER);
      text(p.name,p.pos.x-localPlayer.pos.x+width/2, p.pos.y-localPlayer.pos.y+height/2-45);
      textAlign(LEFT);
      text("player "+ p.name +"  at: X: " + p.pos.x + " Y: " + p.pos.y,10,10+i++*30);
      fill(127,127,127);
      p.update();
      for(Bullet b : localBullets)
      {
        if(frameCount == b.ttl)
        {
          bulletsThatHit.add(b);
        }
        else if(dist(p.pos.x,p.pos.y,b.pos.x,b.pos.y) < b.size/2+p.size/2)
        {
          if(p != localPlayer)
          {
            bulletsThatHit.add(b);
            damagePlayer(p,(byte)10);
          }
        }
      }
    }
    for(Bullet b : bulletsThatHit)
    {
      localBullets.remove(b);
      allBullets.remove(b);
      sendRemoveBullet(b);
    }
    //for(Player p : playersThatWereHit)
    //{
    //  players.remove(p);
    //}
    fill(255,50,0);
    for(Bullet b : allBullets)
    {
        ellipse(b.pos.x-localPlayer.pos.x+width/2, b.pos.y-localPlayer.pos.y+height/2, b.size, b.size);
        b.update();
    }
    fill(0,0,0,0);
    line(width/2,height/2,0-localPlayer.pos.x+width/2, 0-localPlayer.pos.y+height/2);
    rect(50-localPlayer.pos.x+width/2, 50-localPlayer.pos.y+height/2, 30, 30);
  }
}
boolean closed = false;
public void exit()
{
  try
  {
    closed = true;
    sendPlayerLogout();
    syncer.run = false;
    s.close();
  }
  catch(Exception ioe)
  {
    println("Failed to close socket"); 
  }
  t.interrupt();
  println("Exit");
}
class Bullet
{
  byte size = 5;
  PVector pos,velocity;
  long id;
  int ttl;
  public Bullet(PVector pos,PVector velocity,byte size,long id,int ttl)
  {
    this.pos = pos; 
    this.velocity = velocity;
    this.size = size;
    this.id = id;
    this.ttl = ttl;
  }
  public void update()
  {
    this.pos.add(this.velocity); 
  }
}
byte PLAYER = 0b01000000, //64
     DAMAGE = 0b00100000, // 32
     BULLET = 0b00010000, // 16
     CREATE = 0b00001000, // 8
     DESTROY= 0b00000100, // 4
     UPDATE = 0b00000010, // 2
     SET    = 0b00000001; // 1
public void receivePlayerUpdate() throws IOException {
  int len = inStream.read();
  byte[] pack = new byte[len];
  int l = inStream.read(pack);
  println(l + " bytes read");
  if(l!=pack.length)
  {
        System.out.println("Strange packet length " + l + " vs " + pack.length);
  }
  byte newPlayersSize = pack[0];
  long x = pack[1];
  long y = pack[2];

  long activeId = readLongFromByteArray(pack,3);

  for(Player player : players)
  {
    if(player.id == activeId)
    {
       player.velocity = new PVector(x,y);
       break; 
    }
  }
}

public void createPlayer() throws IOException {
  int len = inStream.read();
  byte[] pack = new byte[len];
  int l = inStream.read(pack);
  byte newPlayersSize = pack[0];
  long x = readLongFromByteArray(pack, 1);
  long y = readLongFromByteArray(pack, 9);
  long id = readLongFromByteArray(pack, 17);
  println("Player count: " + players.size());
  for(Player player : players)
  {
    if(player.id == id)
    {
       player.pos = new PVector(x,y);
       println("Updated player: " + player.id + " players new position: " + player.pos);
       return; 
    }
  }
  addPlayer(new Player(new PVector(x, y), new PVector(0, 0), (byte)newPlayersSize,id));
}
public void receiveRemovePlayer() throws IOException {
  int len = inStream.read();
  byte[] pack = new byte[len];
  int l = inStream.read(pack);
  
  long id = readLongFromByteArray(pack, 0);
  Player toRemove = null;
  for(Player player : players)
  {
    if(player.id == id)
    {
       toRemove = player;
       break; 
    }
  }
  if(toRemove != null)
  {
     players.remove(toRemove);
     return;
  }
  //println("Player count: " + players.size());
}
public void createBullet() throws IOException
{
  int len = inStream.read();
  byte[] pack = new byte[len];
  int l = inStream.read(pack);
  byte size = pack[0];
  byte dx = pack[1];
  byte dy = pack[2];
  long x = readLongFromByteArray(pack, 3);
  long y = readLongFromByteArray(pack, 11);
  long id = readLongFromByteArray(pack, 19);
  allBullets.add(new Bullet(new PVector(x,y), new PVector(dx,dy), size,id,-1));
}
public void receiveRemoveBullet() throws IOException {
  int len = inStream.read();
  byte[] pack = new byte[len];
  int l = inStream.read(pack);
  
  long id = readLongFromByteArray(pack, 0);
  Bullet toRemove = null;
  for(Bullet bullet : allBullets)
  {
    if(bullet.id == id)
    {
       toRemove = bullet;
       break;
    }
  }
  if(toRemove != null)
  {
     println("Removed bullet: " + toRemove.id);
     //localBullets.remove(toRemove);
     allBullets.remove(toRemove);
     return;
  }
}

public void receiveDamage() throws IOException {
  int len = inStream.read();
  byte[] pack = new byte[len];
  int l = inStream.read(pack);
  byte damage = pack[0];
  long id = readLongFromByteArray(pack,1);
  Player toDamage = null;
  for(Player player : players)
  {
    if(player.id == id)
    {
       toDamage = player;
       break;
    }
  }
  if(toDamage != null)
  {
     println("Removed bullet: " + toDamage.id);
     toDamage.hp -= damage;
  }
}
public void receiveSetHealth() throws IOException {
  int len = inStream.read();
  byte[] pack = new byte[len];
  int l = inStream.read(pack);
  byte health = pack[0];
  long id = readLongFromByteArray(pack,1);
  Player toDamage = null;
  for(Player player : players)
  {
    if(player.id == id)
    {
       toDamage = player;
       break;
    }
  }
  if(toDamage != null)
  {
     println("Set health for: " + toDamage.id);
     toDamage.hp = health;
  }
}

public void initPlayer(long idToUse)
{
  localPlayer.id = idToUse;
  try {
    byte s = 27;
    long x = (long) localPlayer.pos.x;
    long y = (long) localPlayer.pos.y;
    byte[] pack = new byte[s];
    pack[0] = (byte)(PLAYER | CREATE);
    pack[1] = (byte)(s-2);
    
    pack[2] = localPlayer.size;
    pushLongIntoByteArray(x, pack, 3);
    pushLongIntoByteArray(y, pack, 11);
    pushLongIntoByteArray(idToUse, pack, 19);
    outStream.write(pack);
    println("INIT PLAYER packet: \n-------------");
    for(byte b : pack)
    {
       println((b&0xFF)); 
    }
    println("-------------");
  }
  catch(Exception e)
  {  
    println(e);
  }
}
public void sendPlayerUpdate()
{
  //println("Sending update");
  try 
  {
    byte s = 13;
    long x = (long) localPlayer.velocity.x;
    long y = (long) localPlayer.velocity.y;
    byte[] pack = new byte[s];
    pack[0] = (byte)(PLAYER | UPDATE);
    pack[1] = (byte)(s-2);
    pack[2] = (byte)localPlayer.size;
    pack[3] = (byte)x;
    pack[4] = (byte)y;
    pushLongIntoByteArray(localPlayer.id, pack, 5);
    outStream.write(pack);
    initPlayer(localPlayer.id);
     println("UPDATE PLAYER packet: \n-------------");
    for(byte b : pack)
    {
       println((b&0xFF)); 
    }
    println("-------------");
  }
  catch(Exception e)
  {  
    println(e);
  }
}
public void sendPlayerLogout()
{
  //println("Sending update");
  try 
  {
    byte m = (byte)(PLAYER | DESTROY);
    
    outStream.write(m);
    initPlayer(localPlayer.id);
  }
  catch(Exception e)
  {  
    println(e);
  }
}
public void sendCreateNewBullet(Bullet bullet)
{
  try {
    byte s = 29;
    long x = (long) bullet.pos.x;
    long y = (long) bullet.pos.y;
    byte dx = (byte) bullet.velocity.x;
    byte dy = (byte) bullet.velocity.y;
    byte[] pack = new byte[s];
    pack[0] = (byte)(BULLET | CREATE);
    pack[1] = (byte)(s-2);
    pack[2] = bullet.size;
    pack[3] = dx;
    pack[4] = dy;
    pushLongIntoByteArray(x, pack, 5);
    pushLongIntoByteArray(y, pack, 13);
    pushLongIntoByteArray(bullet.id, pack, 21);
    outStream.write(pack);
  }
  catch(Exception e)
  {  
    println(e);
  }
}
public void sendRemoveBullet(Bullet b)
{
  try {
    byte s = 10;
    byte[] pack = new byte[s];
    pack[0] = (byte)(BULLET | DESTROY);
    pack[1] = (byte)(s-2);
    
    pushLongIntoByteArray(b.id,pack,2);
    outStream.write(pack);
  }
  catch(Exception e)
  {  
    println(e);
  }
}

public void damagePlayer(Player p,byte amount)
{
  p.hp -= amount;
  println("DAMAGE!!!!");
  try {
    byte s = 11;
    byte[] pack = new byte[s];
    pack[0] = (byte)(PLAYER | DAMAGE);
    pack[1] = (byte)(s-2);
    pack[2] = amount;
    pushLongIntoByteArray(p.id,pack,3);
    println("Damage packet: \n-------------");
    for(byte b : pack)
    {
       println((b&0xFF)); 
    }
    println("-------------");
    outStream.write(pack);
  }
  catch(Exception e)
  {  
    println(e);
  }
}
public void setPlayerHealth(Player p,byte amount)
{
  p.hp = amount;
  println("SETTING HEALTH!!!!");
  try {
    byte s = 11;
    byte[] pack = new byte[s];
    pack[0] = (byte)(PLAYER | SET);
    pack[1] = (byte)(s-2);
    pack[2] = (byte)(amount);
    pushLongIntoByteArray(p.id,pack,3);
    outStream.write(pack);
     println("SET HEALTH packet: \n-------------");
    for(byte b : pack)
    {
       println((b&0xFF)); 
    }
    println("-------------");
  }
  catch(Exception e)
  {
    println(e);
  }
}
class Player
{
  byte size = 5;
  PVector pos,velocity;
  long id;
  String name;
  int hp = 100;
  public Player(PVector pos,PVector velocity,byte size,long id)
  {
    this.pos = pos; 
    this.velocity = velocity;
    this.size = size;
    this.id = id;
    byte[] encoded = new byte[8];
    pushLongIntoByteArray(this.id,encoded,0);
    this.name = new String(Base64.getEncoder().encode(encoded));
  }
  public void update()
  {
    this.pos.add(this.velocity); 
  }
}
public class Syncer implements Runnable
{
  InputStream inStream;
  public boolean run = true;
  public Syncer(InputStream inStream)
  {
    this.inStream = inStream;
  }
  public void run()
  {
    try
    {
        while(run)
        {
        //println("Trying to read");
          int in = inStream.read();
          println("Read: " + in);
          
          if((in&PLAYER)!=0)
          {
              if((in&CREATE)!=0)
              {
                  createPlayer();
                  println("Creating player");
                  continue;
              }
              if((in&UPDATE)!=0)
              {
                  receivePlayerUpdate();
                  continue;
              }
              if((in&DAMAGE)!=0)
              {
                  receiveDamage();
                  continue;
              }
              if((in&DESTROY)!=0)
              {
                  receiveRemovePlayer();
                  continue;
              }
               if((in&SET)!=0)
              {
                  receiveSetHealth();
                  continue;
              }
          }
          if((in&BULLET)!=0)
          {
              if((in&CREATE)!=0)
              {
                  createBullet();
                  println("Creating bullet");
                  continue;
              }
             
              if((in&DESTROY)!=0)
              {
                println("Destroying bullet");
                  receiveRemoveBullet();
                  continue;
              }
          }
          //println(in);
          int len = inStream.read();
          byte[] b = new byte[len];
          inStream.read(b);
        }
    }
    catch(IOException ioe)
    {
    
    }
  }
}
  public void settings() {  size(800, 800); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "ShooterClient" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
